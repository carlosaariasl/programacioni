//Calcular área del retangulo
#include <iostream>
#include <cstdio>

using namespace std;


int main(){
    float base, altura, area;
    
    cout <<"Ingrese la base ";
    cin>>base;

    cout<<"Ingrese la altura ";
    cin>>altura;

    area = base * altura;
    cout<<"El area del rectangulo es: %.2f\n", area;

    return 0;
}