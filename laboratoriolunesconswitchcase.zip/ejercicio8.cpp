//Mostrar los numeros del 1 al 10 usando un ciclo
#include <iostream>
#include <cstdio>

using namespace std;


int main(){
    for (int i = 1; i<10; i++){
        printf("%d ", i);
    }
    printf("\n");
    
    return 0;
}

