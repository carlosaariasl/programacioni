//Suma de dos numeros a travez de una funcion
#include <iostream>
#include <cstdio>

using namespace std;


int main(){
    int x,y;
    cout<<"Ingrese dos numero ";
    cin>>x,y;
    printf("La suma es: %d\n" , sumar(x,y));
    return 0;
}

int sumar(int a, int b){
    return a + b;
}
