//Calcular el factorial de un numero
#include <iostream>
#include <cstdio>

using namespace std;

int main(){
    int num;
    long factorial = 1;
    cin >> num;

    for (int i =1; i<=num;i++){
        factorial *= i;
    }

    printf("el factorial es: %ld\n", factorial);

    return 0;
}