//Suma de dos numeros
#include <iostream>
#include <cstdio>

using namespace std;

int main(){
    int a,b;

    cout<<"Ingrese el primer numero: ";
    cin>>a;

    cout<<"Ingrese el segundo numero: ";
    cin>>b;

    cout<<"La suma de los dos numeros anteriores es: " << a+b <<endl;


    return 0;
}