//Hola mundo
#include <iostream>
#include <cstdio>

using namespace std;

int main(){
    cout<<"Hola mundo desde c++" <<endl;
    return 0;
}