//Determinar el mayor de dos numero
#include <iostream>
#include <cstdio>

using namespace std;

int main(){
    int a, b;
    cout<<"Ingrese el primer numero: ";
    scanf("%d",&a);

    cout<<"Ingrese el segundo numero: ";
    cin>>b;

    if (a>b){
        printf("El mayor es: %d\n",a);
    }else{
        printf("El mayor es: %d\n",b);
    }
    return 0;
}