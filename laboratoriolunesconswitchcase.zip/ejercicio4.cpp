//Determinar si un numero es par o impar

#include <iostream>
#include <cstdio>

int main(){
    int num;
    cout<<"Ingrese un numero: ";
    cin>>num;

    if (num%2==0){
        //R"(El numero ingresado es par)";
        printf("El numero ingresado es par")
    }else{
        printf("El numero ingreado es impar");
    }

    return 0;
}