//Sacar el promedio de tres notas
#include <iostream>
#include <cstdio>

using namespace std;


int main(){
    float n1, n2, n3, promedio;
    cout<<"Ingrese tres notas:  ";
    cin>>n1>>n2>>n3;

    promedio = (n1+n2+n3) /3;

    printf("El promedio es: %.2f\n", promedio)

    return 0;
}

