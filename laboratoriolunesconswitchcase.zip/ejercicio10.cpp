//Mostrar la tabla de multiplicar de un numero
#include <iostream>
#include <cstdio>

using namespace std;


int main(){
    int num;

    cout<<"Ingrese un numero: ";
    cin>>num;

    for (int i=1; i<10;i++){
        printf("%d x %d = %d\n",num,i,num*i);
    }

    return 0;
}

